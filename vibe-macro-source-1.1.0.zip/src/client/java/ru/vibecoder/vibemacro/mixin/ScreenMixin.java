package ru.vibecoder.vibemacro.mixin;

import net.minecraft.client.gui.GuiGraphicsExtractor;
import net.minecraft.client.gui.screens.Screen;
import net.minecraft.client.gui.screens.TitleScreen;
import net.minecraft.resources.Identifier;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@Mixin(Screen.class)
abstract class ScreenMixin {
	private static final Identifier VIBEMACRO_BACKGROUND =
		Identifier.fromNamespaceAndPath("vibemacro", "textures/gui/menu_background.png");
	private static final float IMAGE_ASPECT = 1672.0F / 941.0F;

	@Inject(method = "extractPanorama", at = @At("HEAD"), cancellable = true)
	private void vibemacro$drawMenuBackground(GuiGraphicsExtractor graphics, float partialTick, CallbackInfo callback) {
		if (!((Object) this instanceof TitleScreen)) {
			return;
		}

		Screen screen = (Screen) (Object) this;
		float screenAspect = (float) screen.width / (float) screen.height;
		float u0 = 0.0F;
		float v0 = 0.0F;
		float u1 = 1.0F;
		float v1 = 1.0F;

		if (screenAspect > IMAGE_ASPECT) {
			float visibleHeight = IMAGE_ASPECT / screenAspect;
			v0 = (1.0F - visibleHeight) / 2.0F;
			v1 = 1.0F - v0;
		} else {
			float visibleWidth = screenAspect / IMAGE_ASPECT;
			u0 = (1.0F - visibleWidth) / 2.0F;
			u1 = 1.0F - u0;
		}

		// 26.1.2 uses the order u0, u1, v0, v1 here (not u0, v0, u1, v1).
		graphics.blit(VIBEMACRO_BACKGROUND, 0, 0, screen.width, screen.height, u0, u1, v0, v1);
		callback.cancel();
	}
}
