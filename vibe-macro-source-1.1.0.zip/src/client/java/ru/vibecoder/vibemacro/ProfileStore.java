package ru.vibecoder.vibemacro;

import net.fabricmc.loader.api.FabricLoader;

import java.io.IOException;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.StandardCopyOption;
import java.util.Comparator;
import java.util.List;
import java.util.stream.Stream;

final class ProfileStore {
	private static final String DEFAULT_PROFILE = "Скриншот";
	private final Path legacyFile = FabricLoader.getInstance().getConfigDir().resolve("vibemacro.txt");
	private final Path directory = FabricLoader.getInstance().getConfigDir().resolve("vibemacro");
	private final Path profilesDirectory = directory.resolve("profiles");
	private final Path selectedFile = directory.resolve("selected.txt");

	void initialize() throws IOException {
		Files.createDirectories(profilesDirectory);
		if (list().isEmpty()) {
			Path initial = path(DEFAULT_PROFILE);
			if (Files.exists(legacyFile)) {
				Files.copy(legacyFile, initial, StandardCopyOption.REPLACE_EXISTING);
			} else {
				Files.writeString(initial, MacroScript.DEFAULT_SCRIPT, StandardCharsets.UTF_8);
			}
		}
		List<String> profiles = list();
		if (Files.notExists(selectedFile) || !profiles.contains(selected())) {
			select(profiles.getFirst());
		}
	}

	List<String> list() throws IOException {
		if (Files.notExists(profilesDirectory)) {
			return List.of();
		}
		try (Stream<Path> files = Files.list(profilesDirectory)) {
			return files
				.filter(path -> Files.isRegularFile(path) && path.getFileName().toString().endsWith(".txt"))
				.map(path -> path.getFileName().toString())
				.map(name -> name.substring(0, name.length() - 4))
				.sorted(String.CASE_INSENSITIVE_ORDER)
				.toList();
		}
	}

	String selected() throws IOException {
		if (Files.notExists(selectedFile)) {
			List<String> profiles = list();
			return profiles.isEmpty() ? DEFAULT_PROFILE : profiles.getFirst();
		}
		return Files.readString(selectedFile, StandardCharsets.UTF_8).strip();
	}

	void select(String name) throws IOException {
		validateName(name);
		Files.createDirectories(directory);
		Files.writeString(selectedFile, name, StandardCharsets.UTF_8);
	}

	String load(String name) throws IOException {
		return Files.readString(path(name), StandardCharsets.UTF_8);
	}

	void save(String name, String script) throws IOException {
		Files.createDirectories(profilesDirectory);
		Files.writeString(path(name), script, StandardCharsets.UTF_8);
		select(name);
	}

	void create(String name, String initialScript) throws IOException {
		validateName(name);
		Path target = path(name);
		if (Files.exists(target)) {
			throw new IllegalArgumentException("профиль уже существует");
		}
		Files.writeString(target, initialScript, StandardCharsets.UTF_8);
		select(name);
	}

	String delete(String name) throws IOException {
		List<String> profiles = list();
		if (profiles.size() <= 1) {
			throw new IllegalArgumentException("нельзя удалить последний профиль");
		}
		Files.delete(path(name));
		String next = list().stream().min(Comparator.naturalOrder()).orElseThrow();
		select(next);
		return next;
	}

	private Path path(String name) {
		validateName(name);
		return profilesDirectory.resolve(name + ".txt");
	}

	private static void validateName(String name) {
		if (name == null || name.isBlank()) {
			throw new IllegalArgumentException("введите название профиля");
		}
		if (name.length() > 48) {
			throw new IllegalArgumentException("название длиннее 48 символов");
		}
		if (!name.matches("[\\p{L}\\p{N} _.-]+") || name.equals(".") || name.equals("..")) {
			throw new IllegalArgumentException("в названии есть запрещённые символы");
		}
	}
}
