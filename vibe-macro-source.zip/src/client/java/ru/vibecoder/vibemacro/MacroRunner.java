package ru.vibecoder.vibemacro;

import net.minecraft.client.KeyMapping;
import net.minecraft.client.Minecraft;
import net.minecraft.network.chat.Component;
import net.fabricmc.fabric.api.client.keymapping.v1.KeyMappingHelper;

import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.concurrent.Executors;
import java.util.concurrent.ScheduledExecutorService;
import java.util.concurrent.TimeUnit;

final class MacroRunner {
	private final Minecraft client;
	private final ScheduledExecutorService scheduler = Executors.newSingleThreadScheduledExecutor(runnable -> {
		Thread thread = new Thread(runnable, "vibe-macro-timer");
		thread.setDaemon(true);
		return thread;
	});
	private final Set<KeyMapping> heldKeys = new HashSet<>();
	private final Map<Integer, Long> loopRemaining = new HashMap<>();
	private List<MacroCommand> commands = List.of();
	private int programCounter;
	private long generation;
	private boolean running;

	MacroRunner(Minecraft client) {
		this.client = client;
	}

	boolean isRunning() {
		return running;
	}

	void start(List<MacroCommand> newCommands) {
		stop(false);
		commands = newCommands;
		programCounter = 0;
		loopRemaining.clear();
		running = true;
		long runGeneration = generation;
		message("Vibe Macro: запущен (" + commands.size() + " команд)");
		advance(runGeneration);
	}

	void stop(boolean announce) {
		generation++;
		running = false;
		loopRemaining.clear();
		releaseAll();
		if (announce) {
			message("Vibe Macro: остановлен, все кнопки отпущены");
		}
	}

	private void advance(long runGeneration) {
		if (!running || runGeneration != generation) {
			return;
		}
		if (programCounter >= commands.size()) {
			stop(false);
			message("Vibe Macro: сценарий завершён");
			return;
		}

		MacroCommand command = commands.get(programCounter++);
		switch (command.type()) {
			case PRESS -> {
				setKey(command, true);
				advance(runGeneration);
			}
			case RELEASE -> {
				setKey(command, false);
				advance(runGeneration);
			}
			case TAP -> {
				KeyMapping mapping = resolve(command);
				KeyMapping.click(KeyMappingHelper.getBoundKeyOf(mapping));
				mapping.setDown(true);
				heldKeys.add(mapping);
				schedule(runGeneration, command.value(), () -> {
					mapping.setDown(false);
					heldKeys.remove(mapping);
					advance(runGeneration);
				});
			}
			case WAIT -> schedule(runGeneration, command.value(), () -> advance(runGeneration));
			case LOOP -> {
				int loopIndex = programCounter - 1;
				long remaining = loopRemaining.getOrDefault(loopIndex, command.value() - 1);
				if (remaining > 0) {
					loopRemaining.put(loopIndex, remaining - 1);
					programCounter = 0;
				} else {
					loopRemaining.remove(loopIndex);
				}
				advance(runGeneration);
			}
		}
	}

	private void schedule(long runGeneration, long delayMs, Runnable action) {
		scheduler.schedule(() -> client.execute(() -> {
			if (running && runGeneration == generation) {
				action.run();
			}
		}), delayMs, TimeUnit.MILLISECONDS);
	}

	private void setKey(MacroCommand command, boolean down) {
		KeyMapping mapping = resolve(command);
		mapping.setDown(down);
		if (down) {
			heldKeys.add(mapping);
		} else {
			heldKeys.remove(mapping);
		}
	}

	private KeyMapping resolve(MacroCommand command) {
		KeyMapping result = switch (command.key()) {
			case "W", "FORWARD" -> client.options.keyUp;
			case "S", "BACK" -> client.options.keyDown;
			case "A", "LEFT" -> client.options.keyLeft;
			case "D", "RIGHT" -> client.options.keyRight;
			case "SPACE", "JUMP" -> client.options.keyJump;
			case "SHIFT", "SNEAK" -> client.options.keyShift;
			case "CTRL", "SPRINT" -> client.options.keySprint;
			case "ATTACK", "LMB", "MOUSE1" -> client.options.keyAttack;
			case "USE", "RMB", "MOUSE2" -> client.options.keyUse;
			default -> null;
		};
		if (result == null) {
			throw new IllegalArgumentException("строка " + command.sourceLine() + ": неизвестная кнопка '" + command.key() + "'");
		}
		return result;
	}

	private void releaseAll() {
		for (KeyMapping mapping : heldKeys) {
			mapping.setDown(false);
		}
		heldKeys.clear();
	}

	private void message(String text) {
		if (client.player != null) {
			client.player.sendSystemMessage(Component.literal(text));
		}
	}
}
