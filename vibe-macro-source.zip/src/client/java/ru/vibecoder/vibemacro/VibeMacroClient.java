package ru.vibecoder.vibemacro;

import com.mojang.blaze3d.platform.InputConstants;
import net.fabricmc.api.ClientModInitializer;
import net.fabricmc.fabric.api.client.event.lifecycle.v1.ClientTickEvents;
import net.fabricmc.fabric.api.client.keymapping.v1.KeyMappingHelper;
import net.fabricmc.loader.api.FabricLoader;
import net.minecraft.client.KeyMapping;
import net.minecraft.client.Minecraft;
import net.minecraft.network.chat.Component;
import net.minecraft.resources.Identifier;

import java.io.IOException;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.List;

public final class VibeMacroClient implements ClientModInitializer {
	private static final Path SCRIPT_PATH = FabricLoader.getInstance().getConfigDir().resolve("vibemacro.txt");
	private static final KeyMapping.Category CATEGORY = KeyMapping.Category.register(
		Identifier.fromNamespaceAndPath("vibemacro", "main")
	);

	private KeyMapping toggleKey;
	private KeyMapping reloadKey;
	private MacroRunner runner;
	private List<MacroCommand> commands = List.of();

	@Override
	public void onInitializeClient() {
		toggleKey = KeyMappingHelper.registerKeyMapping(new KeyMapping(
			"key.vibemacro.toggle", InputConstants.Type.KEYSYM, InputConstants.KEY_F8, CATEGORY
		));
		reloadKey = KeyMappingHelper.registerKeyMapping(new KeyMapping(
			"key.vibemacro.reload", InputConstants.Type.KEYSYM, InputConstants.KEY_F9, CATEGORY
		));

		runner = new MacroRunner(Minecraft.getInstance());
		loadScript(false);

		ClientTickEvents.END_CLIENT_TICK.register(client -> {
			while (toggleKey.consumeClick()) {
				if (runner.isRunning()) {
					runner.stop(true);
				} else if (client.player != null && loadScript(false)) {
					runner.start(commands);
				}
			}
			while (reloadKey.consumeClick()) {
				if (runner.isRunning()) {
					runner.stop(false);
				}
				loadScript(true);
			}
			if (runner.isRunning() && client.player == null) {
				runner.stop(false);
			}
		});
	}

	private boolean loadScript(boolean announce) {
		Minecraft client = Minecraft.getInstance();
		try {
			if (Files.notExists(SCRIPT_PATH)) {
				Files.createDirectories(SCRIPT_PATH.getParent());
				Files.writeString(SCRIPT_PATH, MacroScript.DEFAULT_SCRIPT, StandardCharsets.UTF_8);
			}
			commands = MacroScript.parse(Files.readString(SCRIPT_PATH, StandardCharsets.UTF_8));
			if (announce && client.player != null) {
				client.player.sendSystemMessage(Component.literal("Vibe Macro: сценарий загружен, команд: " + commands.size()));
			}
			return true;
		} catch (IOException | IllegalArgumentException exception) {
			if (client.player != null) {
				client.player.sendSystemMessage(Component.literal("Vibe Macro: ошибка: " + exception.getMessage()));
			}
			return false;
		}
	}
}
