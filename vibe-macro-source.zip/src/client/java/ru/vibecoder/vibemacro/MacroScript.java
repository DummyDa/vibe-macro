package ru.vibecoder.vibemacro;

import java.util.ArrayList;
import java.util.List;
import java.util.Locale;

final class MacroScript {
	static final String DEFAULT_SCRIPT = """
		# Пресет со скриншота. Время указывается в миллисекундах.
		TAP ATTACK 35
		WAIT 64
		PRESS W
		WAIT 64
		WAIT 64
		WAIT 9200
		RELEASE W
		PRESS A
		WAIT 9200
		RELEASE A
		LOOP 40
		PRESS S
		WAIT 48000
		RELEASE S
		LOOP 10000
		""";

	private MacroScript() {
	}

	static List<MacroCommand> parse(String text) {
		List<MacroCommand> result = new ArrayList<>();
		String[] lines = text.split("\\R", -1);
		for (int index = 0; index < lines.length; index++) {
			String rawLine = lines[index];
			int commentStart = rawLine.indexOf('#');
			String line = (commentStart >= 0 ? rawLine.substring(0, commentStart) : rawLine).strip();
			int sourceLine = index + 1;
			if (line.isEmpty() || line.startsWith("#")) {
				continue;
			}

			String[] parts = line.split("\\s+");
			String instruction = parts[0].toUpperCase(Locale.ROOT);
			try {
				switch (instruction) {
					case "PRESS", "DOWN" -> {
						requireParts(parts, 2, sourceLine);
						result.add(new MacroCommand(MacroCommand.Type.PRESS, normalizeKey(parts[1]), 0, sourceLine));
					}
					case "RELEASE", "UP" -> {
						requireParts(parts, 2, sourceLine);
						result.add(new MacroCommand(MacroCommand.Type.RELEASE, normalizeKey(parts[1]), 0, sourceLine));
					}
					case "TAP", "CLICK" -> {
						if (parts.length != 2 && parts.length != 3) {
							throw new IllegalArgumentException("ожидалось: TAP <кнопка> [длительность]");
						}
						long duration = parts.length == 3 ? parsePositive(parts[2], sourceLine) : 35;
						result.add(new MacroCommand(MacroCommand.Type.TAP, normalizeKey(parts[1]), duration, sourceLine));
					}
					case "WAIT", "SLEEP" -> {
						requireParts(parts, 2, sourceLine);
						result.add(new MacroCommand(MacroCommand.Type.WAIT, "", parsePositive(parts[1], sourceLine), sourceLine));
					}
					case "LOOP", "REPEAT" -> {
						requireParts(parts, 2, sourceLine);
						result.add(new MacroCommand(MacroCommand.Type.LOOP, "", parsePositive(parts[1], sourceLine), sourceLine));
					}
					default -> throw new IllegalArgumentException("неизвестная команда '" + parts[0] + "'");
				}
			} catch (NumberFormatException exception) {
				throw new IllegalArgumentException("строка " + sourceLine + ": число записано неверно", exception);
			} catch (IllegalArgumentException exception) {
				if (exception.getMessage().startsWith("строка ")) {
					throw exception;
				}
				throw new IllegalArgumentException("строка " + sourceLine + ": " + exception.getMessage(), exception);
			}
		}
		if (result.isEmpty()) {
			throw new IllegalArgumentException("сценарий пуст");
		}
		return List.copyOf(result);
	}

	private static String normalizeKey(String value) {
		String key = value.toUpperCase(Locale.ROOT);
		return switch (key) {
			case "W", "FORWARD", "S", "BACK", "A", "LEFT", "D", "RIGHT",
				"SPACE", "JUMP", "SHIFT", "SNEAK", "CTRL", "SPRINT",
				"ATTACK", "LMB", "MOUSE1", "USE", "RMB", "MOUSE2" -> key;
			default -> throw new IllegalArgumentException("неизвестная кнопка '" + value + "'");
		};
	}

	private static void requireParts(String[] parts, int count, int line) {
		if (parts.length != count) {
			throw new IllegalArgumentException("строка " + line + ": неверное количество аргументов");
		}
	}

	private static long parsePositive(String value, int line) {
		long parsed = Long.parseLong(value);
		if (parsed < 1) {
			throw new IllegalArgumentException("строка " + line + ": число должно быть больше нуля");
		}
		return parsed;
	}
}
