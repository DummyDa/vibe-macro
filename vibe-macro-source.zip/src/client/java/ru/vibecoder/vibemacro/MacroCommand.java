package ru.vibecoder.vibemacro;

record MacroCommand(Type type, String key, long value, int sourceLine) {
	enum Type {
		PRESS,
		RELEASE,
		TAP,
		WAIT,
		LOOP
	}
}
