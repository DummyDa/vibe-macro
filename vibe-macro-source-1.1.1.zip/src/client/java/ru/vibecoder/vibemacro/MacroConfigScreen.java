package ru.vibecoder.vibemacro;

import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.GuiGraphicsExtractor;
import net.minecraft.client.gui.components.Button;
import net.minecraft.client.gui.components.CycleButton;
import net.minecraft.client.gui.components.EditBox;
import net.minecraft.client.gui.components.MultiLineEditBox;
import net.minecraft.client.gui.screens.Screen;
import net.minecraft.network.chat.Component;

import java.io.IOException;
import java.util.List;

final class MacroConfigScreen extends Screen {
	private final Screen parent;
	private final MacroRunner runner;
	private final ProfileStore store;
	private String profile;
	private MultiLineEditBox editor;
	private EditBox newProfileName;
	private Button runButton;
	private String status = "Команды: PRESS, RELEASE, TAP, WAIT, LOOP";
	private int statusColor = 0xA0A0A0;

	MacroConfigScreen(Screen parent, MacroRunner runner, ProfileStore store) {
		super(Component.literal("Vibe Macro — редактор"));
		this.parent = parent;
		this.runner = runner;
		this.store = store;
		try {
			this.profile = store.selected();
		} catch (IOException exception) {
			this.profile = "Скриншот";
			setError(exception);
		}
	}

	@Override
	protected void init() {
		int contentWidth = Math.min(720, width - 24);
		int left = (width - contentWidth) / 2;
		int top = 32;
		List<String> profiles;
		try {
			profiles = store.list();
		} catch (IOException exception) {
			profiles = List.of(profile);
			setError(exception);
		}

		CycleButton<String> selector = CycleButton
			.builder(Component::literal, profile)
			.withValues(profiles)
			.create(left, top, contentWidth, 20, Component.literal("Профиль"), (button, value) -> switchProfile(value));
		addRenderableWidget(selector);

		int manageTop = top + 24;
		int actionWidth = Math.min(86, (contentWidth - 12) / 3);
		int nameWidth = contentWidth - actionWidth * 2 - 12;
		newProfileName = new EditBox(font, left, manageTop, nameWidth, 20, Component.literal("Название нового профиля"));
		newProfileName.setMaxLength(48);
		newProfileName.setHint(Component.literal("Название (можно оставить пустым)"));
		addRenderableWidget(newProfileName);

		addRenderableWidget(Button.builder(Component.literal("Создать"), button -> createProfile())
			.bounds(left + nameWidth + 6, manageTop, actionWidth, 20).build());
		Button deleteButton = Button.builder(Component.literal("Удалить"), button -> deleteProfile())
			.bounds(left + nameWidth + actionWidth + 12, manageTop, actionWidth, 20).build();
		deleteButton.active = profiles.size() > 1;
		addRenderableWidget(deleteButton);

		int editorTop = manageTop + 27;
		int editorHeight = Math.max(80, height - editorTop - 58);
		editor = MultiLineEditBox.builder()
			.setX(left)
			.setY(editorTop)
			.setPlaceholder(Component.literal("Введите команды макроса…"))
			.build(font, contentWidth, editorHeight, Component.literal("Сценарий профиля " + profile));
		editor.setCharacterLimit(100_000);
		addRenderableWidget(editor);
		loadEditor(profile);

		int bottom = height - 26;
		int buttonWidth = (contentWidth - 12) / 3;
		addRenderableWidget(Button.builder(Component.literal("Сохранить"), button -> saveProfile())
			.bounds(left, bottom, buttonWidth, 20).build());
		runButton = addRenderableWidget(Button.builder(runLabel(), button -> toggleRun())
			.bounds(left + buttonWidth + 6, bottom, buttonWidth, 20).build());
		addRenderableWidget(Button.builder(Component.literal("Закрыть"), button -> onClose())
			.bounds(left + (buttonWidth + 6) * 2, bottom, contentWidth - (buttonWidth + 6) * 2, 20).build());
	}

	@Override
	public void tick() {
		super.tick();
		if (runButton != null) {
			runButton.setMessage(runLabel());
		}
	}

	@Override
	public void extractRenderState(GuiGraphicsExtractor graphics, int mouseX, int mouseY, float partialTick) {
		super.extractRenderState(graphics, mouseX, mouseY, partialTick);
		graphics.centeredText(font, title, width / 2, 10, 0xFFFFFF);
		graphics.centeredText(font, status, width / 2, height - 40, statusColor);
	}

	@Override
	public void onClose() {
		minecraft.setScreen(parent);
	}

	@Override
	public boolean isPauseScreen() {
		return false;
	}

	private void switchProfile(String value) {
		if (value.equals(profile)) {
			return;
		}
		if (!saveProfile()) {
			return;
		}
		profile = value;
		try {
			store.select(profile);
			loadEditor(profile);
			setStatus("Открыт профиль «" + profile + "»");
		} catch (IOException exception) {
			setError(exception);
		}
	}

	private void loadEditor(String name) {
		try {
			editor.setValue(store.load(name));
		} catch (IOException exception) {
			setError(exception);
		}
	}

	private boolean saveProfile() {
		try {
			MacroScript.parse(editor.getValue());
			store.save(profile, editor.getValue());
			setStatus("Профиль «" + profile + "» сохранён");
			return true;
		} catch (IOException | IllegalArgumentException exception) {
			setError(exception);
			return false;
		}
	}

	private void createProfile() {
		try {
			String name = newProfileName.getValue().strip();
			if (name.isEmpty()) {
				name = nextDefaultName();
			}
			store.create(name, editor.getValue());
			minecraft.setScreen(new MacroConfigScreen(parent, runner, store));
		} catch (IOException | IllegalArgumentException exception) {
			setError(exception);
		}
	}

	private String nextDefaultName() throws IOException {
		List<String> existing = store.list();
		for (int number = 1; ; number++) {
			String candidate = "Профиль " + number;
			if (!existing.contains(candidate)) {
				return candidate;
			}
		}
	}

	private void deleteProfile() {
		try {
			store.delete(profile);
			minecraft.setScreen(new MacroConfigScreen(parent, runner, store));
		} catch (IOException | IllegalArgumentException exception) {
			setError(exception);
		}
	}

	private void toggleRun() {
		if (runner.isRunning()) {
			runner.stop(true);
			setStatus("Макрос остановлен");
			return;
		}
		if (!saveProfile()) {
			return;
		}
		try {
			runner.start(MacroScript.parse(editor.getValue()));
			setStatus("Макрос запущен — F8 остановит его в любой момент");
		} catch (IllegalArgumentException exception) {
			setError(exception);
		}
	}

	private Component runLabel() {
		return Component.literal(runner.isRunning() ? "Остановить" : "Запустить");
	}

	private void setStatus(String value) {
		status = value;
		statusColor = 0x70FF70;
	}

	private void setError(Exception exception) {
		status = "Ошибка: " + exception.getMessage();
		statusColor = 0xFF6060;
	}
}
